require("wizard/wizard").default.create().start();
//# sourceMappingURL=/assets/wizard-start-f75db482663dacc9c68ea5c6646139b8074b762cce2788a09dafdb993b3f99a0.js.map